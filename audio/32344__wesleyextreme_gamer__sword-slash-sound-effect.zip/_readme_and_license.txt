Pack downloaded from Freesound
----------------------------------------

"sword Slash sound effect"

This Pack of sounds contains sounds by the following user:
 - wesleyextreme_gamer ( https://freesound.org/people/wesleyextreme_gamer/ )

You can find this pack online at: https://freesound.org/people/wesleyextreme_gamer/packs/32344/


Licenses in this Pack (see below for individual sound licenses)
---------------------------------------------------------------

Creative Commons 0: http://creativecommons.org/publicdomain/zero/1.0/


Sounds in this Pack
-------------------

  * 574821__wesleyextreme_gamer__slash1.ogg.ogg
    * url: https://freesound.org/s/574821/
    * license: Creative Commons 0
  * 574820__wesleyextreme_gamer__slash2.ogg.ogg
    * url: https://freesound.org/s/574820/
    * license: Creative Commons 0


